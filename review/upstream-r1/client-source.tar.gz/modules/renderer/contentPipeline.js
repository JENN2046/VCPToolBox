// modules/renderer/contentPipeline.js

/**
 * 统一内容预处理流水线
 *
 * 设计目标：
 * 1. 显式化顺序协议，避免预处理逻辑分散后顺序漂移
 * 2. 区分 full-render 与 stream-fast 两种模式
 * 3. 让“保护 -> 结构修正 -> 恢复”成为固定流程
 *
 * 注意：
 * - 本模块当前以“集中调度”为主，不强行重写既有处理器实现
 * - 业务细节（特殊块转换、HTML fenced 等）通过依赖注入提供
 */

import { PIPELINE_MODES } from '../chat/contentModes.js';
import { replaceMarkdownCodeDomains } from './markdownCodeDomainScanner.js';
import { stripEmotionTags } from '../emotion/emotionTags.js';
import {
    collectToolResultRanges,
    collectClosedToolResultRanges,
    maskToolResults,
    transformOutsideToolResults,
} from './toolResultRegions.js';

function noop(value) {
    return value;
}

// OpenHerPersona 回填注释（persona_delta / persona_expression）需要从渲染中剥离。
// 不能简单"从开标记删到文末"——VCP 工具循环会把工具调用等后续内容追加在同一条
// 消息里，贪婪剥离会把回填之后的工具调用块一并吞掉。这里用与插件服务端同款的
// 字符串感知括号配平扫描，精确删除每个回填块（即使 reason 里出现 "-->" 也不会
// 提前截断泄漏），并保留其后的全部内容；流式半截回填则剥到文末。
const PERSONA_BACKFILL_OPEN_REGEX = /<!--\s*persona_(?:delta|expression)\s*:/g;

function findPersonaJsonEnd(text, startIndex) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = startIndex; i < text.length; i++) {
        const ch = text[i];
        if (inString) {
            if (escaped) escaped = false;
            else if (ch === '\\') escaped = true;
            else if (ch === '"') inString = false;
            continue;
        }
        if (ch === '"') inString = true;
        else if (ch === '{') depth++;
        else if (ch === '}') {
            depth--;
            if (depth === 0) return i + 1;
        }
    }
    return -1;
}

function stripPersonaBackfillTail(text) {
    if (!text || text.indexOf('persona_') === -1) return text;
    // 工具结果是权威数据域：其中出现的 persona 注释只是数据，不能被剥离；
    // 工具结果之前的半截回填也只能剥到工具结果边界，不得吞掉整个工具结果。
    return transformOutsideToolResults(text, stripPersonaBackfillSegment);
}

// 情绪标签 <!--emo:happy 0.8--> 只给立绘等助手形象看，显示时剥掉；工具结果里的同样是数据，不动。
// 流式时连尾巴上没写完的半个标签一起藏起来，免得闪出 "<!--emo"。
function stripEmotionTagsOutsideToolResults(text, streaming) {
    if (!text || text.indexOf('<!') === -1) return text;
    return transformOutsideToolResults(text, segment => stripEmotionTags(segment, { streaming }));
}

function stripPersonaBackfillSegment(text) {
    if (!text || text.indexOf('persona_') === -1) return text;
    let result = '';
    let cursor = 0;
    let strippedAny = false;
    PERSONA_BACKFILL_OPEN_REGEX.lastIndex = 0;
    let match;
    while ((match = PERSONA_BACKFILL_OPEN_REGEX.exec(text)) !== null) {
        if (match.index < cursor) continue;
        result += text.slice(cursor, match.index);
        const jsonStart = text.indexOf('{', match.index + match[0].length);
        if (jsonStart === -1) { cursor = text.length; strippedAny = true; break; }
        const jsonEnd = findPersonaJsonEnd(text, jsonStart);
        if (jsonEnd === -1) { cursor = text.length; strippedAny = true; break; }
        let end = jsonEnd;
        const closer = text.indexOf('-->', jsonEnd);
        if (closer !== -1 && text.slice(jsonEnd, closer).trim() === '') {
            end = closer + 3;
        }
        cursor = end;
        strippedAny = true;
        PERSONA_BACKFILL_OPEN_REGEX.lastIndex = end;
    }

    if (!strippedAny) {
        return text;
    }

    result += text.slice(cursor);
    return result;
}

function normalizeAdjacentBoldBoundaries(text) {
    if (typeof text !== 'string' || !text.includes('**')) return text;

    // marked/CommonMark 的 emphasis 边界算法在中文/引号无空格相邻时会把
    // **“文字a”**文字b**""文字c""**
    // 解析成嵌套 strong。HTML 注释是 Markdown 认可的不可见边界，
    // 可强制结束前一个粗体并重新开始后一个粗体，不改变可见文本。
    const separator = '<!-- -->';
    let result = '';
    let cursor = 0;
    let inBold = false;

    const needsSeparatorAfter = (char) => !!char && !/\s/.test(char) && char !== '<' && char !== '*';
    const needsSeparatorBefore = (char) => !!char && !/\s/.test(char) && char !== '>' && char !== '*';

    while (cursor < text.length) {
        const markerIndex = text.indexOf('**', cursor);
        if (markerIndex === -1) {
            result += text.slice(cursor);
            break;
        }

        const previousChar = markerIndex > 0 ? text[markerIndex - 1] : '';

        result += text.slice(cursor, markerIndex);

        if (!inBold && result && !result.endsWith(separator) && needsSeparatorBefore(previousChar)) {
            result += separator;
        }

        result += '**';
        cursor = markerIndex + 2;
        inBold = !inBold;

        if (!inBold) {
            const nextChar = text[cursor] || '';
            if (needsSeparatorAfter(nextChar)) {
                result += separator;
            }
        }
    }

    return result;
}

function createMapPlaceholderReplacer(map) {
    if (!map || map.size === 0) {
        return noop;
    }

    return (text) => {
        let result = text;
        for (const [placeholder, original] of map.entries()) {
            if (result.includes(placeholder)) {
                result = result.replace(placeholder, () => original);
            }
        }
        return result;
    };
}

function createContentPipeline(deps = {}) {
    const {
        escapeHtml = (text) => text,
        processStartEndMarkers = (text) => text,
        fixEmoticonUrlsInMarkdown = (text) => text,
        deIndentMisinterpretedCodeBlocks = (text) => text,
        deIndentHtml = (text) => text,
        deIndentToolRequestBlocks = (text) => text,
        applyContentProcessors = (text) => text,
        transformSpecialBlocks = (text) => text,
        ensureHtmlFenced = (text) => text,
        transformMermaidPlaceholders = (text) => text,
        transformFlowlockBlocks = (text) => text,
        getToolResultRegex = null,
        getToolRequestRegex = null,
        replaceToolRequestBlocks = null,
        deferToolRequest = null,
        getCodeFenceRegex = null,
        getDesktopPushRegex = null,
        getDesktopPushPartialRegex = null,
    } = deps;

    function createContext(inputText, options = {}) {
        return {
            mode: options.mode || PIPELINE_MODES.FULL_RENDER,
            text: typeof inputText === 'string' ? inputText : '',
            options,
            meta: {
                stepsApplied: []
            },
            state: {
                thoughtChainMap: null,
                toolResultMap: null,
                toolRequestMap: null,
                codeBlockMap: null,
                thoughtChainPlaceholderId: 0,
                toolResultPlaceholderId: 0,
                toolRequestPlaceholderId: 0,
                codeBlockPlaceholderId: 0
            }
        };
    }

    function step(ctx, name, handler) {
        ctx.text = handler(ctx.text, ctx) ?? ctx.text;
        ctx.meta.stepsApplied.push(name);
        return ctx;
    }

    function protectThoughtChains(text, ctx) {
        if (
            typeof text !== 'string' ||
            (!text.includes('[--- VCP元思考链') && !/<think(?:ing)?>/i.test(text))
        ) {
            return text;
        }

        ctx.state.thoughtChainMap = new Map();

        // 工具结果优先级高于思维链：先以等长空白遮蔽（保持偏移与换行），
        // 其内部的 <think> / 元思考链 / 围栏都不参与扫描；并以工具结果为硬边界，
        // 跨越工具结果的思维链视为未闭合，不得把工具结果吞进思维链渲染域。
        const toolResultRanges = collectToolResultRanges(text);
        const scanText = maskToolResults(text, toolResultRanges);
        let toolResultCursor = 0;
        const lineOverlapsToolResult = (lineStart, lineEnd) => {
            while (
                toolResultCursor < toolResultRanges.length
                && toolResultRanges[toolResultCursor].end <= lineStart
            ) {
                toolResultCursor += 1;
            }
            const range = toolResultRanges[toolResultCursor];
            return !!range && range.start < lineEnd;
        };

        // 使用围栏感知的逐行扫描器，避免把 Markdown 代码块中用于说明协议的
        // <think> 或 VCP 元思考链示例误识别为真实思维链。
        const lineRegex = /.*(?:\r\n|\n|\r|$)/g;
        const ranges = [];
        let activeFence = null;
        let activeThought = null;
        let lineMatch;

        while ((lineMatch = lineRegex.exec(scanText)) !== null) {
            const line = lineMatch[0];
            if (line === '' && lineMatch.index === scanText.length) break;

            if (toolResultRanges.length > 0 && lineOverlapsToolResult(lineMatch.index, lineMatch.index + line.length)) {
                activeThought = null;
                continue;
            }

            const lineWithoutEnding = line.replace(/\r\n|\n|\r$/, '');
            const fenceMatch = lineWithoutEnding.match(/^[ \t]{0,3}(`{3,}|~{3,})(.*)$/);

            if (fenceMatch) {
                const marker = fenceMatch[1];
                const trailingText = fenceMatch[2] || '';

                if (!activeFence) {
                    activeFence = {
                        char: marker[0],
                        length: marker.length
                    };
                } else if (
                    marker[0] === activeFence.char &&
                    marker.length >= activeFence.length &&
                    trailingText.trim() === ''
                ) {
                    activeFence = null;
                }

                continue;
            }

            if (activeFence) continue;

            if (!activeThought) {
                const customStart = lineWithoutEnding.match(
                    /^[ \t]*\[--- VCP元思考链(?::\s*"[^"]*")?\s*---\][ \t]*$/
                );
                const conventionalStart = lineWithoutEnding.match(
                    /^[ \t]*<(think(?:ing)?)>[ \t]*$/i
                );

                if (customStart) {
                    activeThought = {
                        start: lineMatch.index,
                        type: 'custom'
                    };
                } else if (conventionalStart) {
                    activeThought = {
                        start: lineMatch.index,
                        type: conventionalStart[1].toLowerCase()
                    };
                }
                continue;
            }

            const isEnd = activeThought.type === 'custom'
                ? /^[ \t]*\[--- 元思考链结束 ---\][ \t]*$/.test(lineWithoutEnding)
                : new RegExp(`^[ \\t]*<\\/${activeThought.type}>[ \\t]*$`, 'i').test(lineWithoutEnding);

            if (isEnd) {
                ranges.push({
                    start: activeThought.start,
                    end: lineMatch.index + line.length
                });
                activeThought = null;
            }
        }

        if (ranges.length === 0) return text;

        // 从后向前替换以保持前面范围的字符串偏移稳定。
        let result = text;
        for (let i = ranges.length - 1; i >= 0; i--) {
            const range = ranges[i];
            const original = text.slice(range.start, range.end);
            const placeholder = `<!--VCP_THOUGHT_CHAIN_${ctx.state.thoughtChainPlaceholderId}-->`;
            ctx.state.thoughtChainMap.set(placeholder, original);
            ctx.state.thoughtChainPlaceholderId += 1;
            result = result.slice(0, range.start) + placeholder + result.slice(range.end);
        }

        return result;
    }

    function protectToolResults(text, ctx) {
        // 未注入工具结果能力的流水线不做保护（保持原有依赖注入契约）。
        if (typeof getToolResultRegex !== 'function') return text;

        // 嵌套感知配对：工具结果内部成对出现的字面量起止标记（例如读取渲染器源码）
        // 被整体包含在最外层工具结果中，不会在第一个内层结束标记处截断。
        // 占位符序号与删除功能（removeToolResultFromMessage）使用同一配对规则，保持一致。
        const ranges = collectClosedToolResultRanges(text);
        if (ranges.length === 0) return text;

        ctx.state.toolResultMap = new Map();
        let result = '';
        let cursor = 0;
        for (const range of ranges) {
            // 🟢 架构级修复：工具结果块保持原始内容不做任何转义
            // 占位符将贯穿整个 Markdown 解析过程，在 parse() 之后才恢复为渲染好的 HTML
            // 🔴 关键：使用 HTML 注释格式，避免 __ 被 Markdown 解释为粗体
            const placeholder = `<!--VCP_TOOL_RESULT_${ctx.state.toolResultPlaceholderId}-->`;
            ctx.state.toolResultMap.set(placeholder, text.slice(range.start, range.end));
            ctx.state.toolResultPlaceholderId += 1;
            result += text.slice(cursor, range.start) + placeholder;
            cursor = range.end;
        }
        return result + text.slice(cursor);
    }

    function protectToolRequests(text, ctx) {
        const toolRequestRegex = typeof getToolRequestRegex === 'function' ? getToolRequestRegex() : null;
        if (!toolRequestRegex && typeof replaceToolRequestBlocks !== 'function') return text;

        const hasToolRequests = text.includes('<<<[TOOL_REQUEST]>>>');
        if (!hasToolRequests) return text;

        ctx.state.toolRequestMap = new Map();
        ctx.state.toolRequestSourceMap = new Map();

        const protectMatch = (match, content) => {
            // 「始/末」标记是 Tool Request 字段语法的一部分，只应在工具请求围栏内部生效。
            // 因此在保护工具请求时局部处理字段内容，后续全局流水线不再扫描裸「始/末」。
            const placeholder = `<!--VCP_TOOL_REQUEST_${ctx.state.toolRequestPlaceholderId}-->`;
            const deferredHtml = deferToolRequest?.(match, content);
            if (typeof deferredHtml === 'string') {
                ctx.state.toolRequestMap.set(placeholder, deferredHtml);
                ctx.state.toolRequestPlaceholderId += 1;
                return placeholder;
            }
            const escapedMatch = processStartEndMarkers(match);
            ctx.state.toolRequestMap.set(placeholder, escapedMatch);
            // 工具气泡在输出处自己转义一次，需要字段转义之前的原文；按转义后的整块查回。
            if (typeof content === 'string') ctx.state.toolRequestSourceMap.set(escapedMatch, content);
            ctx.state.toolRequestPlaceholderId += 1;
            return placeholder;
        };

        if (typeof replaceToolRequestBlocks === 'function') {
            return replaceToolRequestBlocks(text, protectMatch);
        }

        toolRequestRegex.lastIndex = 0;
        const result = text.replace(toolRequestRegex, protectMatch);
        toolRequestRegex.lastIndex = 0;
        return result;
    }

    function restoreToolRequests(text, ctx) {
        return createMapPlaceholderReplacer(ctx.state.toolRequestMap)(text);
    }

    function protectCodeBlocks(text, ctx) {
        if (typeof text !== 'string' || (!text.includes('`') && !text.includes('~~~'))) return text;

        ctx.state.codeBlockMap = new Map();
        return replaceMarkdownCodeDomains(text, (match) => {
            const placeholder = `__VCP_CODE_BLOCK_PLACEHOLDER_${ctx.state.codeBlockPlaceholderId}__`;
            ctx.state.codeBlockMap.set(placeholder, match);
            ctx.state.codeBlockPlaceholderId += 1;
            return placeholder;
        });
    }

    function restoreCodeBlocks(text, ctx) {
        if (!ctx.state.codeBlockMap || ctx.state.codeBlockMap.size === 0) return text;
        let result = text;
        for (const [placeholder, original] of ctx.state.codeBlockMap.entries()) {
            result = result.split(placeholder).join(original);
        }
        return result;
    }

    function transformDesktopPush(text, ctx) {
        const desktopPushRegex = typeof getDesktopPushRegex === 'function' ? getDesktopPushRegex() : null;
        const desktopPushPartialRegex = typeof getDesktopPushPartialRegex === 'function' ? getDesktopPushPartialRegex() : null;
        if (!desktopPushRegex || !desktopPushPartialRegex) return text;

        desktopPushRegex.lastIndex = 0;
        desktopPushPartialRegex.lastIndex = 0;

        let result = text.replace(desktopPushRegex, (match, rawContent) => {
            const content = rawContent.trim();
            const escapedPreview = escapeHtml(content.length > 120 ? content.substring(0, 120) + '...' : content);
            return `<div class="vcp-desktop-push-placeholder">` +
                `<div class="vcp-desktop-push-header">` +
                `<span class="vcp-desktop-push-icon">🖥️</span>` +
                `<span class="vcp-desktop-push-label">已推送到桌面画布</span>` +
                `</div>` +
                `<div class="vcp-desktop-push-preview"><pre>${escapedPreview}</pre></div>` +
                `</div>`;
        });

        result = result.replace(desktopPushPartialRegex, (match, partialContent) => {
            const content = partialContent.trim();
            const lines = content.split('\n');
            const totalLines = lines.length;
            const tailLines = lines.slice(-3).join('\n');
            const escapedPreview = escapeHtml(tailLines.length > 120 ? tailLines.substring(tailLines.length - 120) : tailLines);
            const lineCountInfo = totalLines > 3 ? `(${totalLines} 行)` : '';
            return `<div class="vcp-desktop-push-placeholder constructing">` +
                `<div class="vcp-desktop-push-header">` +
                `<span class="vcp-desktop-push-icon">🖥️</span>` +
                `<span class="vcp-desktop-push-label">正在向桌面推送 ${escapeHtml(lineCountInfo)}<span class="thinking-indicator-dots">...</span></span>` +
                `</div>` +
                `<div class="vcp-desktop-push-preview"><pre>${escapedPreview}</pre></div>` +
                `</div>`;
        });

        desktopPushRegex.lastIndex = 0;
        desktopPushPartialRegex.lastIndex = 0;

        return result;
    }

    function runFullRenderPipeline(inputText, options = {}) {
        const ctx = createContext(inputText, { ...options, mode: PIPELINE_MODES.FULL_RENDER });

        if ((options.messageRole || 'assistant') === 'assistant') {
            step(ctx, 'strip-persona-backfill-tail', (text) => stripPersonaBackfillTail(text));
            step(ctx, 'strip-emotion-tags', (text) => stripEmotionTagsOutsideToolResults(text, false));
        }
        step(ctx, 'normalize-emoticon-urls', (text) => fixEmoticonUrlsInMarkdown(text));

        // 顺序协议：
        // 1. 最先隔离完整思维链。其内部只允许专用渲染器处理 Markdown 与 LaTeX，
        // 禁止工具、Mermaid、Flowlock、桌面推送等外层特殊协议介入。
        step(ctx, 'protect-thought-chains', protectThoughtChains);

        // 2. 再做工具结果保护（它们可能包含任意内容，包括代码块、标记等）
        step(ctx, 'protect-tool-results', protectToolResults);

        // 3. 再保护工具请求，并在 protectToolRequests 内部局部处理「始/末」字段标记。
        // 「始/末」不再作为全局正文语法，避免普通聊天提及这些标记时触发额外转义或渲染扰动。
        step(ctx, 'protect-tool-requests', protectToolRequests);

        // 3. 工具请求之外不再扫描裸「始/末」标记。
        step(ctx, 'transform-mermaid-placeholders', (text) => transformMermaidPlaceholders(text));

        // 4. 保护代码块
        step(ctx, 'protect-code-blocks', protectCodeBlocks);

        // 5. 在工具结果、工具请求、代码围栏仍为占位符时转换 Flowlock 控制块。
        // Flowlock 协议解析器还会自行排除思维链、桌面推送和行内代码，
        // 因此工具内容中的同名标记不会被误识别或渲染。
        if ((options.messageRole || 'assistant') === 'assistant') {
            step(ctx, 'transform-flowlock-blocks', (text) => transformFlowlockBlocks(text, ctx));
        }

        // 6. 再做会改变行首语义/结构边界的修正
        step(ctx, 'deindent-misinterpreted-code-blocks', (text) => deIndentMisinterpretedCodeBlocks(text));
        step(ctx, 'deindent-html', (text) => deIndentHtml(text));
        step(ctx, 'deindent-tool-request-blocks', (text) => deIndentToolRequestBlocks(text));

        // 7. 再做结构转换
        step(ctx, 'transform-desktop-push', transformDesktopPush);

        // 8. 🟢 架构级修复：不再恢复工具结果
        // 工具结果占位符将贯穿 Markdown 解析，在 parse() 之后才由调用方替换为渲染好的 HTML
        // 这彻底避免了工具结果内部的 Markdown 语法（表格、代码围栏等）干扰外部解析

        // 8. 只恢复工具请求。思维链继续保持占位符，直到 transformSpecialBlocks
        // 已完成工具、日记、角色分隔等全部外层协议转换后才由专用渲染器恢复。
        step(ctx, 'restore-tool-requests', restoreToolRequests);

        // 9. 特殊块转换（工具结果与思维链仍为占位符）。
        step(ctx, 'transform-special-blocks', (text) => transformSpecialBlocks(
            text,
            ctx.state.codeBlockMap,
            ctx.state.thoughtChainMap,
            ctx.state.toolRequestSourceMap
        ));
        step(ctx, 'ensure-html-fenced', (text) => ensureHtmlFenced(text));
        step(ctx, 'apply-common-content-processors', (text) => applyContentProcessors(text));

        // 10. Markdown 解析前修复相邻粗体边界；此时代码块仍是占位符，避免污染代码内容。
        step(ctx, 'normalize-adjacent-bold-boundaries', normalizeAdjacentBoldBoundaries);

        // 11. 最后恢复代码块
        step(ctx, 'restore-code-blocks', restoreCodeBlocks);

        return {
            text: ctx.text,
            meta: ctx.meta,
            state: ctx.state
        };
    }

    function runStreamFastPipeline(inputText, options = {}) {
        const ctx = createContext(inputText, { ...options, mode: PIPELINE_MODES.STREAM_FAST });

        // 流式快路径只保留轻量、幂等、低风险修正。
        // 注意：「始/末」仅属于工具请求围栏内部字段语法；流式尾部不做全局扫描，
        // 防止普通正文提及该语法时被提前转义或造成排版抖动。
        step(ctx, 'strip-persona-backfill-tail', (text) => stripPersonaBackfillTail(text));
        step(ctx, 'strip-emotion-tags', (text) => stripEmotionTagsOutsideToolResults(text, true));
        step(ctx, 'normalize-emoticon-urls', (text) => fixEmoticonUrlsInMarkdown(text));
        step(ctx, 'protect-code-blocks', protectCodeBlocks);
        step(ctx, 'deindent-misinterpreted-code-blocks', (text) => deIndentMisinterpretedCodeBlocks(text));
        step(ctx, 'apply-common-content-processors', (text) => applyContentProcessors(text));
        step(ctx, 'normalize-adjacent-bold-boundaries', normalizeAdjacentBoldBoundaries);
        step(ctx, 'restore-code-blocks', restoreCodeBlocks);

        return {
            text: ctx.text,
            meta: ctx.meta,
            state: ctx.state
        };
    }

    function process(inputText, options = {}) {
        const mode = options.mode || PIPELINE_MODES.FULL_RENDER;
        if (mode === PIPELINE_MODES.STREAM_FAST) {
            return runStreamFastPipeline(inputText, options);
        }
        return runFullRenderPipeline(inputText, options);
    }

    return {
        process,
        runFullRenderPipeline,
        runStreamFastPipeline
    };
}

export {
    PIPELINE_MODES,
    createContentPipeline
};
